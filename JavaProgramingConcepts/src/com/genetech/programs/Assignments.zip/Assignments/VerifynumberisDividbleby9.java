package com.genetech.programs.Assignments;

public class VerifynumberisDividbleby9 {

	public static void main(String[] args) {
		int num =100;
		if(num%9==00){
			System.out.println(num +"is dividable by 9");		
		}else {
			System.out.println("not diviable by 9");
		}
	}

}
