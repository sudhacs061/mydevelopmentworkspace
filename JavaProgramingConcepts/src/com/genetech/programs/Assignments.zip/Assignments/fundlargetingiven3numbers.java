package com.genetech.programs.Assignments;

public class fundlargetingiven3numbers {

	public static void main(String[] args) {

		int a=10;
		int b=20;
		int c=30;
		if(a>b) {
			System.out.println(a +" is greater than "+b);
		}else if(a>c){
			System.out.println(a +" is greater than "+c);

		}else if(b>c) {
			System.out.println(b +" is greater than "+a);
	}else {
		System.out.println(c +" is greater than"+ a +"and "+b);

	}
	}

}
