package com.genetech.programs.Assignments;

public class VerifyoddNumber {

	public static void main(String args[]) {
	
	int num =43;
			if(num%2!=0){
		System.out.println(num +"is odd number");
			}
	}
}
