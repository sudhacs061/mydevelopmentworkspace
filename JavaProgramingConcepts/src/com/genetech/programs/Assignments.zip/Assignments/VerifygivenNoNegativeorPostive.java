package com.genetech.programs.Assignments;

public class VerifygivenNoNegativeorPostive {

	public static void main(String[] args) {

		int num =-45;
		if(num>0){
			System.out.println(num +"is postive number");
		}
		else if(num<0){
			System.out.println("it is negative number");
		}


	}
}


