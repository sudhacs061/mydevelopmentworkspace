package com.genetech.programs.Assignments;

public class monthNamesbySwitchStatment {

	public static void main(String[] args) {
		String a="10";

		switch(a) {
		case "1":
			System.out.println(a +" is jan");
			break;
		case "2":
			System.out.println(a +" is Feb");
			break;
		case "3":
			System.out.println(a +" is March");
			break;

		case "4":
			System.out.println(a +"is April");

			break;

		case "5":
			System.out.println(a +"is May");
			break;

		case "6":
			System.out.println(a+" is June");
			break;

		case "7":
			System.out.println(a +" is July");
			break;

		case "8":
			System.out.println(a +" is August");
			break;

		case "9":
			System.out.println(a +" is September");
			break;

		case "10":
			System.out.println(a +" is October");
			break;

		case "11":
			System.out.println(a +" is November");
			break;

		case "12":
			System.out.println(a +" is Dcenmber");
			break;

		default:						
			System.out.println(a +" is invalid no to dispaly the month");


		}
	}
}
