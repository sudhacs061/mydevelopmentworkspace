package com.genetech.programs.Assignments;

public class Verifynumberdividableby2468 {

	public static void main(String[] args) {
		int num =240;
		if(num%2==0&&num%6==0&&num%4==0&&num%8==0){
			System.out.println(num +"is dividable by 2,4,6  and 8 number");		
		}else {
			System.out.println("not diviable by 2,4,6,and 8");
		}
	}
}

