package com.genetech.programs.Assignments;

public class verifyNumberisdividedby3and6 {

	public static void main(String[] args) {
		int num =100;
		if(num%3==0&&num%6==0){
	System.out.println(num +"is dividable by 3  and 6 number");		
}else {
	System.out.println("not diviable by 3 and6");
}
	}

}
