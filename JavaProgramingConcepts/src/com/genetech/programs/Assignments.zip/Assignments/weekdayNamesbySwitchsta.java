package com.genetech.programs.Assignments;

public class weekdayNamesbySwitchsta {

	public static void main(String[] args) {
	
				int a=10;
				
				switch(a) {
				case '1':
					System.out.println(a +" is sunday");
					break;
				case '2':
					System.out.println(a +" is Monday");
					break;

				case '3':
					System.out.println(a +" is Tuesay");
					break;

				case '4':
						System.out.println(a +"is Wednesday");
						break;

				case '5':
						System.out.println(a+" is Thursday");
						break;

	            case '6':
						System.out.println(a +" is Friday");
						break;

	            case '7':
						System.out.println(a +" is Saturday");
						break;

				default :
				System.out.println(a +" is invalid no to dispaly the weekday");

			}
			
		}
}	

