package com.genetech.programs.Assignments;

public class WeekdaynameDisplay {

	public static void main(String[] args) {
		int a=10;

		if(a==1) {
			System.out.println(a +" is sunday");
		}else if(a==2){
			System.out.println(a +" is Monday");

		}else if(a==3) {
			System.out.println(a +" is Tuesay");

		}else if(a==4){
			System.out.println(a +"is Wednesday");

		}else if(a==5) {
			System.out.println(a+" is Thursday");
		}
		else if(a==6) {
			System.out.println(a +" is Friday");
		}
		else if(a==7) {
			System.out.println(a +" is Saturday");
		}
		else {
			System.out.println(a +" is invalid no to dispaly the weekday");

		}

	}
}
